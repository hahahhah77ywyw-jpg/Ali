package com.example.alothmanysender;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
    SenderView v;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(4,16,24));getWindow().setNavigationBarColor(Color.rgb(4,16,24));v=new SenderView(this);setContentView(v);}
    class SenderView extends View {
        Paint p=new Paint(3); int page=0; float den; int W,H; int cyan=Color.rgb(0,201,240), gold=Color.rgb(215,164,45), bg=Color.rgb(5,18,28), card=Color.rgb(8,28,40), white=Color.rgb(236,244,248), muted=Color.rgb(150,170,180); RectF r=new RectF();
        String[] tabs={"الرئيسية","الانضمام","الاستخراج","الفحص","النشر","التشخيص"}; String[] icons={"⌂","♟","⇩","⌕","➤","⚙"};
        SenderView(Context c){super(c);den=getResources().getDisplayMetrics().density;p.setTypeface(Typeface.create("sans",Typeface.NORMAL));setBackgroundColor(bg);}
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size*den);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextAlign(Paint.Align.RIGHT);c.drawText(s,x,y,p);}
        void center(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size*den);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);}
        void round(Canvas c,float l,float t,float rr,float bb,int color,float rad){p.setStyle(Paint.Style.FILL);p.setColor(color);r.set(l,t,rr,bb);c.drawRoundRect(r,rad,rad,p);p.setStyle(Paint.Style.FILL);}
        void stroke(Canvas c,float l,float t,float rr,float bb,int color,float rad){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2*den);p.setColor(color);r.set(l,t,rr,bb);c.drawRoundRect(r,rad,rad,p);p.setStyle(Paint.Style.FILL);}
        @Override protected void onDraw(Canvas c){W=getWidth();H=getHeight();c.drawColor(bg); float d=den; drawHeader(c); drawPage(c); drawTabs(c);}
        void drawHeader(Canvas c){text(c,"Al-othmany Sender",W-28*den,43*den,22,white,true);text(c,"إدارة الروابط، الانضمام، الاستخراج، الفحص، النشر",W-28*den,69*den,12,muted,false);}
        void banner(Canvas c,String title,String sub,int color){float l=22*den,t=88*den,rr=W-22*den;round(c,l,t,rr,t+132*den,card,28*den);stroke(c,l,t,rr,t+132*den,color,28*den);text(c,title,rr-30*den,t+55*den,25,white,true);text(c,sub,rr-30*den,t+88*den,14,muted,false);}
        void status(Canvas c,float top){round(c,22*den,top,W-22*den,top+120*den,card,24*den);stroke(c,22*den,top,W-22*den,top+120*den,gold,24*den);text(c,"الملف الشخصي • واتساب • غير جاهز",W-42*den,top+35*den,18,white,true);text(c,"Accessibility محددة يدوياً لكنها غير متصلة داخل الملف الشخصي",W-42*den,top+66*den,13,muted,false);text(c,"الحالة: يحتاج إعداد",W-42*den,top+98*den,14,gold,true);}
        void drawPage(Canvas c){if(page==0){banner(c,"مرحباً بك","كل ما تحتاجه لإدارة مجموعاتك في مكان واحد",cyan);status(c,238*den);section(c,"التحكم السريع",390);button(c,22,430,210,500,"إعداد الملف",cyan);button(c,226,430,392,500,"فحص الروابط",cyan);button(c,22,515,210,585,"استخراج",cyan);button(c,226,515,392,585,"النشر",cyan);}
          else if(page==1){banner(c,"الانضمام","إدارة طلبات الانضمام والتحقق والتنفيذ",cyan);status(c,238*den);box(c,"روابط الدعوة",380,"الصق روابط الدعوة هنا...\nرابط واحد في كل سطر");button(c,42,535,370,602,"استيراد من ملف",cyan);stats(c,630);}
          else if(page==2){banner(c,"الاستخراج","استخراج الروابط من القروبات والمحادثات",cyan);status(c,238*den);button(c,22,380,205,445,"بدء الاستخراج",Color.rgb(45,60,74));button(c,215,380,392,445,"مزامنة القروبات",Color.rgb(35,90,150));box(c,"وضع الاستخراج الذكي",470,"ذكي     جديد فقط     عميق\nالأداء الموحد: استخراج سريع ومعالجة محلية");section(c,"محرك الاستخراج الذكي",640);}
          else if(page==3){banner(c,"الفحص","يفحص الرابط ويقرأ حالة الوصول فقط — بدون تنفيذ انضمام",cyan);status(c,238*den);box(c,"روابط الفحص",380,"الصق روابط الدعوة هنا...\nرابط واحد في كل سطر");button(c,42,535,160,602,"إضافة",cyan);button(c,166,535,266,602,"ملف",Color.rgb(45,90,180));button(c,272,535,370,602,"من الاستخراج",Color.rgb(90,55,160));box(c,"وضع الفحص الآمن",625,"التصنيف فقط: لا ينفذ التطبيق انضمام أو طلب انضمام\nالأداء الموحد: فحص واحد لكل رابط");}
          else if(page==4){banner(c,"النشر","إدارة نشر الرسائل على القروبات المحددة",cyan);status(c,238*den);box(c,"رسالة النشر",380,"اكتب الرسالة هنا...\nيمكنك اختيار روابط من قائمة الاستخراج");button(c,42,535,370,602,"اختيار الروابط",cyan);box(c,"وضع النشر",625,"محلي وآمن: تجهيز النصوص والقوائم فقط\nيمكنك نسخ النتائج ومشاركتها مع واتساب");}
          else {banner(c,"التشخيص","فحص حالة التطبيق وإعدادات الجهاز",cyan);status(c,238*den);box(c,"حالة المكونات",380,"التخزين المحلي: جاهز\nالوصول للملفات: حسب صلاحيات النظام\nالخدمات الخارجية: غير مطلوبة للوظائف المحلية");button(c,42,555,370,622,"إعادة فحص الحالة",cyan);}
        }
        void section(Canvas c,String s,float y){text(c,s,W-28*den,y*den,21,white,true);}
        void button(Canvas c,float l,float t,float rr,float b,String s,int color){round(c,l*den,t*den,rr*den,b*den,card,18*den);stroke(c,l*den,t*den,rr*den,b*den,color,18*den);center(c,s,(l+rr)/2*den,(t+b)/2*den+7*den,16,white,true);}
        void box(Canvas c,String title,float top,String content){round(c,22*den,top*den,W-22*den,(top+140)*den,card,24*den);stroke(c,22*den,top*den,W-22*den,(top+140)*den,cyan,24*den);text(c,title,W-42*den,(top+38)*den,21,white,true);String[] ls=content.split("\\n");for(int i=0;i<ls.length;i++)text(c,ls[i],W-42*den,(top+72+i*28)*den,14,muted,false);}
        void stats(Canvas c,float top){for(int i=0;i<3;i++){float l=22+i*123;round(c,l*den,top*den,(l+112)*den,(top+90)*den,card,18*den);center(c,"0",(l+56)*den,(top+38)*den,22,i==0?cyan:(i==1?Color.GREEN:gold),true);center(c,i==0?"الكل":(i==1?"تم الانضمام":"موافقة المشرف"),(l+56)*den,(top+67)*den,12,white,false);}}
        void drawTabs(Canvas c){float top=H-86*den;round(c,0,top,W,H,bg,0);for(int i=0;i<6;i++){float l=i*W/6f; if(i==page)round(c,l+10*den,top+7*den,l+W/6f-10*den,H-9*den,Color.rgb(4,66,86),28*den);center(c,icons[i],l+W/12f,top+32*den,23,i==page?cyan:white,true);center(c,tabs[i],l+W/12f,top+62*den,12,i==page?cyan:muted,true);}}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();if(y>H-105*den){int i=(int)(x/(W/6f));if(i>=0&&i<6){page=i;invalidate();}}return true;}
    }
}
